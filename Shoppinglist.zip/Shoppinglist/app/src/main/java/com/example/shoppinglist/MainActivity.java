package com.example.shoppinglist;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    // make class attributes from important variables
    ListView listView = null;

    // this static arraylists can be access from any activity
    private static ArrayList<Item> itemList;
    private static ArrayList<Purchase> purchaseList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // initialise attributes
        listView = findViewById(R.id.listView);

        itemList = new ArrayList<Item>();
        purchaseList = new ArrayList<Purchase>();

        // add items (this should come from database)
        itemList.add(new Item("001", "pen", 10.00, 5));
        itemList.add(new Item("002", "ball", 20.00, 6));
        itemList.add(new Item("003", "eraser", 30.00, 7));

        // set item layout using adapter class
        MyAdapter adapter = new MyAdapter(this, itemList);
        listView.setAdapter(adapter);

        // impliment onclick listener for each list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // navigate to Item_Details_Activity
                Intent myIntent = new Intent(MainActivity.this, Item_Details_Activity.class);
                // pass array index of item to Item_Details_Activity
                myIntent.putExtra("array_index", position);
                // open Item_Details_Activity
                MainActivity.this.startActivity(myIntent);
            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    // get getItemList
    public static ArrayList<Item> getItemList() {

        return itemList;
    }
    public static ArrayList<Purchase> getPurchaseList() {

        return purchaseList;
    }
    // add item object to array list using given index
    public static void setItemElement(int index, Item item) {

        itemList.set(index, item);
    }
    // add purchase object to array list using given index
    public static void addPurchaseElement(Purchase purchase) {

        purchaseList.add(purchase);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // adapter class
    class MyAdapter extends ArrayAdapter<Item> {

        Context context;

        // create local item list
        ArrayList<Item> rItemList;

        // impliment constracter and assign values to attributes
        MyAdapter(Context c, ArrayList<Item> pItemList) {

            super(c,0, pItemList);

            rItemList = new ArrayList<Item>();

            this.context = c;

            rItemList = pItemList;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            // this method add contents to list view
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            // assign values to text views
            View listItem = layoutInflater.inflate(R.layout.list_item_layout, parent, false);
            TextView itemName = listItem.findViewById(R.id.textView_name);
            TextView itemPrice = listItem.findViewById(R.id.textView_price);

            // set resources
            itemName.setText(rItemList.get(position).getName());
            itemPrice.setText(Double.toString(rItemList.get(position).getPrice()));

            return listItem;
        }
    }
}
