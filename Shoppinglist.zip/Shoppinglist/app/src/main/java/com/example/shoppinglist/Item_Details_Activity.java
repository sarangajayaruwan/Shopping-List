package com.example.shoppinglist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class Item_Details_Activity extends AppCompatActivity {

    // intialise important variables as attributes
    Item item;
    int arrIndex;

    String name;
    double price;
    int amount;

    EditText buyAmount;
    TextView total;
    TextView itemAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item__details_);

        Intent myNextIntent = getIntent();

        // get arrayList index no from previous activity
        arrIndex = myNextIntent.getIntExtra("array_index", 0);
        // get relevent item object from array list in MainActivity
        item = MainActivity.getItemList().get(arrIndex);

        // assign item attributes to variables
        name = item.getName();
        price = item.getPrice();
        amount = item.getAmount();

        // selects important views to objects
        TextView itemName = findViewById(R.id.name_textView);
        TextView itemPrice = findViewById(R.id.price_textView);
        itemAmount = findViewById(R.id.amount_textView);
        buyAmount = findViewById(R.id.buy_amount_editText);
        total = findViewById(R.id.total_TextView);

        // set values to relevent views using their objects
        itemName.setText(name);
        itemPrice.setText(Double.toString(price));
        itemAmount.setText(Integer.toString(amount));
        buyAmount.setText("0");
        total.setText("0.00");

        // select and get button to object
        Button addCartButton = findViewById(R.id.add_cart_btn);

        // implimant onclick listener event
        addCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // check text edit value is integer
                if (!isInteger(buyAmount.getText().toString()))
                {
                    Toast.makeText(Item_Details_Activity.this, "Please enter a valied amount", Toast.LENGTH_LONG).show();
                }
                else
                    {
                    int intBuyAmount = Integer.parseInt(buyAmount.getText().toString());

                    // check text edit value is zero
                    if (intBuyAmount == 0)
                    {
                        Toast.makeText(Item_Details_Activity.this, "Please enter the amount", Toast.LENGTH_LONG).show();
                    }
                    // check text edit value is grater than available amount
                    else if (intBuyAmount > amount)
                    {
                        Toast.makeText(Item_Details_Activity.this, "Sorry! This amount is not available", Toast.LENGTH_LONG).show();
                    }
                    else
                        {// if text edit value is valied number process add cart
                            //update available amount of item
                            amount -= intBuyAmount;
                        // set item total
                        total.setText(Double.toString(intBuyAmount * price));
                        itemAmount.setText(Integer.toString(amount));
                            // update amount of item in item array list
                            item.setAmount(amount);

                            MainActivity.setItemElement(arrIndex, item);
                        // create purchase object and add it to purchase array list
                        MainActivity.addPurchaseElement(new Purchase(item.getCode(), item.getName(), intBuyAmount * price));

                    }
                }
            }
        });

        // select button and impliment onclcik event for it
        Button viewCartButton = findViewById(R.id.view_cart_btn);
        viewCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // navigate to Item_Details_Activity
                Intent myIntent = new Intent(Item_Details_Activity.this, View_Details_Activity.class);
                // pass arraylist index to Item_Details_Activity
                myIntent.putExtra("array_index", arrIndex);

                Item_Details_Activity.this.startActivity(myIntent);
            }
        });
    }

    public static boolean isInteger(String s) {
        boolean isValidInteger = false;
        try
        {
            Integer.parseInt(s);

            // s is a valid integer

            isValidInteger = true;
        }
        catch (NumberFormatException ex)
        {
            // s is not an integer
        }

        return isValidInteger;
    }

}
