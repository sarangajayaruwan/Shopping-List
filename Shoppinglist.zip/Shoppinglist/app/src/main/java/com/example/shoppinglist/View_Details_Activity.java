package com.example.shoppinglist;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class View_Details_Activity extends AppCompatActivity {

    // create class attributes for important varibles (make global)
    ListView listView = null;

    ArrayList<Purchase> purchaseList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view__details_);

        // get index of array from previous activity
        Intent myNextIntent = getIntent();

        int arrIndex = myNextIntent.getIntExtra("array_index", 0);
        // get purchase objects to array list
        purchaseList = MainActivity.getPurchaseList();
        listView = findViewById(R.id.listView);

        // create list view contents using adapter class
        View_Details_Activity.MyAdapter adapter = new View_Details_Activity.MyAdapter(this, purchaseList);
        listView.setAdapter(adapter);

        // get net total and set it to text view
        TextView netTotal = findViewById(R.id.total_textView);
        netTotal.setText(Double.toString(getNetTotal()));
    }
// calculate net total
    public double getNetTotal()
    {
        double netTotal = 0;
        for(int i = 0; i<purchaseList.size(); i++)
        {
            netTotal += purchaseList.get(i).getValue();
        }
        return netTotal;
    }
// adapter class
    class MyAdapter extends ArrayAdapter<Purchase> {
        // class attributes
        Context context;

        ArrayList<Purchase> rPurchaseList;
        // impliment constructor and assign values to class attributes
        MyAdapter(Context c, ArrayList<Purchase> pPurchaseList) {

            super(c,0, pPurchaseList);

            rPurchaseList = new ArrayList<Purchase>();

            this.context = c;

            rPurchaseList = pPurchaseList;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // this method add contents (purchase item details) to list view using layout (view_details_list_content)
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            // select and get views to objects
            View listItem = layoutInflater.inflate(R.layout.view_details_list_content, parent, false);
            TextView itemName = listItem.findViewById(R.id.textView_name);
            TextView itemValue = listItem.findViewById(R.id.textView_value);

            // set resources
            itemName.setText(rPurchaseList.get(position).getName());
            itemValue.setText(Double.toString(rPurchaseList.get(position).getValue()));

            return listItem;
        }
    }
}
